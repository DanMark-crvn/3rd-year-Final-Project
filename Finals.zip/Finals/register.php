<?php 

include("includes/connection.php");

$output = "";

if (isset($_POST['register'])) {
	
	$idnumber = $_POST['idnum'];
	$fullname = $_POST['fullnme'];
	$yrlvlC = $_POST['yrlvlc'];
	$ustype = $_POST['utype'];
	$unme = $_POST['uname'];
	$pass = $_POST['pass'];
	$c_pass = $_POST['c_pass'];

	$error = array();

	if (empty($idnumber)) {
		$error['error'] = "Id number is Empty";
	}else if(empty($fullname)){
		$error['error'] = "Full name is empty";
	}else if(empty($yrlvlC)){
		$error['error'] = "Year level & Course is empty";
	}else if(empty($ustype)){
		$error['error'] = "Select user type";
	}else if(empty($unme)){
		$error['error'] = "Username is empty";
	}else if(empty($pass)){
		$error['error'] = "Enter Password";
	}else if(empty($c_pass)){
		$error['error'] = "Confirm Password";
	}else if($pass != $c_pass){
		$error['error'] = "Both password do not match";
	}



	if (isset($error['error'])) {
		$output .= $error['error'];
	}else{
		$output .= "";
	}


	if (count($error) < 1) {
		
		$query = "INSERT INTO users(idNum,fullName,yrlvlCourse,userType,username,password) VALUES('$idnumber','$fullname','$yrlvlC','$ustype','$unme','$pass')";
		$res = mysqli_query($connect,$query);

		if ($res) {
			$output .= "You have successfully registered";
			header("Location:index.php");
		}else{
			$output .= "Failed to register";
		}
	}
}



 ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Register</title>
</head>
<style type="text/css">
	.bgcolor{
		background-color: whitesmoke;
	}
	.container{
		position: fixed;
		top: -10%;
		right: 40%;
	}
	form{
		background-color: white;
		padding: 15px;
	}
	h3{
		font-family: 'Poppins', sans-serif;
	}
	.bgimg{
		position: fixed;
		right: 100px;
		bottom: 200px;
		height: 50%;

    	}

	.img img{
		position: fixed;
		right: 30px;
		bottom: 150px;
		height: 60%;
		width: 60%;
	}
	lord-icon{
		position: relative;
		left: 24%;
	}
</style>
<body class="bgcolor">

	<?php include("includes/headeregis.php"); ?>
<img class="bgimg" src="img/bg.png">
	<div class="imgqr">
		<div class="img">
			<img src="img/illregis.svg">
		</div>


	<div class="container">
		<div class="col-md-12">
			<div class="row d-flex justify-content-center">
				<div class="col-md-6 shadow-sm" style="margin-top:80px;">
					<form method="post">
						<h3 class="text-center my-3">Register</h3>

						<div class="text-center"><?php echo $output; ?></div>

						<label>Id Number</label>
						<input type="text" name="idnum" class="form-control my-2" placeholder="Enter Id number" autocomplete="off">

						<label>Full Name</label>
						<input type="text" name="fullnme" class="form-control my-2" placeholder="Enter Full Name" autocomplete="off">
                         
                         <label>Year Level & Course</label>
						<input type="text" name="yrlvlc" class="form-control my-2" placeholder="Enter Year Level & Course" autocomplete="off">

                         <label>Select User Type</label>
						<select name="utype" class="form-control my-2">
							<option value="0" disabled selected>Choose user type</option>
							<option value="Student">Student</option>
							<option value="Professor">Professor</option>
							<option value="Admin">Admin</option>
						</select>

						<label>Username</label>
						<input type="text" name="uname" class="form-control my-2" placeholder="Enter Username" autocomplete="off">

						<label>Password</label>
						<input type="password" name="pass" class="form-control my-2" placeholder="Enter Password">

						<label>Confirm Password</label>
						<input type="password" name="c_pass" class="form-control my-2" placeholder="Enter Confirm Password">

						<input type="submit" name="register" class="btn btn-success" value="Register">
					</form>
				</div>
			</div>
		</div>
	</div>

	<div class="" style="margin-top: 30px;"></div>

</body>
</html>