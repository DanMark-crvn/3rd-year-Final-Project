<!DOCTYPE html>
<html>
<head>
	<title>Student</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/a81368914c.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
	<img class="wave" src="img/bg.png">
	<div class="container">
		<div class="img">
			<img src="img/stud.png">
		</div>
		<div class="login-content">
			<form action="index.php">
				<h2 class="title">Welcome Student</h2>
				<input type="button" href="#" class="btn" value="Update Profile">
				<input type="button" href="#" class="btn" value="View enrolled subjects">
				<input type="button" href="#" class="btn" value="View previous record of TimeIn & TimeOut">
				<input type="button" href="#" class="btn" value="Record TimeIn & TimeOut for a subject">
				<input type="submit" href="index.php" class="btn" value="Logout">
            </form>
        </div>
    </div>
    <script type="text/javascript" src="js/main.js"></script>
</body>
</html>
