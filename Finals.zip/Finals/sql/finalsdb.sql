-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 15, 2022 at 08:44 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `multilogin`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL,
  `idNum` varchar(100) NOT NULL,
  `fullName` varchar(100) NOT NULL,
  `yrlvlCourse` varchar(100) NOT NULL,
  `userType` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `idNum`, `fullName`, `yrlvlCourse`, `userType`, `username`, `password`) VALUES
(6, 'P12-56787', 'Professor', 'Professor 3rd year BSCS', 'Professor', 'Professor', 'professor'),
(5, 'A12-3456', 'Admin', 'Admin 3rd year BSCS', 'Admin', 'admin', 'admin'),
(4, 'B17-11608', 'Jayne-lyn Arenas', '3rd year BSCS', 'Student', 'jynee', 'hakdog'),
(7, 'B18-12443', 'Dan Mark Caravana', '3rd year BSCS', 'Student', 'dnmrk', 'dandan'),
(8, 'A23-45678', 'New Admin', 'Admin 3rd year BSCS', 'Admin', 'newadmin', 'admin'),
(9, 'P85-32436', 'New professor', 'Professor 3rd year BSCS', 'Professor', 'newprof', 'prof'),
(10, 'B19-11708', 'Paul Bonaobra', '3rd year BSCS', 'Student', 'polly', 'polly');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
