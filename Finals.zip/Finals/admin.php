<!DOCTYPE html>
<html>
<head>
	<title>Administrator</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/a81368914c.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
	<img class="wave" src="img/bg.png">
	<div class="container">
		<div class="img">
			<img src="img/admin.png">
		</div>
		<div class="login-content">
			<form action="index.php">
				<h2 class="title">Welcome Admin</h2>
				<input type="button" href="#" class="btn" value="Update Profile">
				<input type="button" href="#" class="btn" value="Add Subject">
				<input type="button" href="#" class="btn" value="Remove Subject">
				<input type="button" href="#" class="btn" value="Assign subject to Professor">
				<input type="button" href="#" class="btn" value="Assign subject to Student">
				<input type="button" href="#" class="btn" value="Remove subject to a Professor">
				<input type="button" href="#" class="btn" value="Remove subject to a Student">
				<input type="submit" href="index.php" class="btn" value="Logout">
            </form>
        </div>
    </div>
    <script type="text/javascript" src="js/main.js"></script>
</body>
</html>
