<?php 
session_start();
  include("includes/connection.php");

   
   $output = "";

  if (isset($_POST['login'])) {
  	   
  	   $unme = $_POST['uname'];
  	   $ustype = $_POST['utype'];
  	   $pass = $_POST['pass'];

  	   if (empty($unme)) {
  	   	
  	   }else if(empty($ustype)){

  	   }else if(empty($pass)){

  	   }else{

         $query = "SELECT * FROM users WHERE username='$unme' AND userType='$ustype' AND password='$pass'";
         $res = mysqli_query($connect,$query);

         if (mysqli_num_rows($res) == 1) {

         	  if ($ustype == "Student") {

         	  	$_SESSION['student'] = $unme;
         	  	header("Location: student.php");
         	  	
         	  }else if($ustype == "Professor"){
                
                $_SESSION['professor'] = $unme;
                header("Location: professor.php");

         	  }else if($ustype == "Admin"){
                
                $_SESSION['admin'] = $unme;
                header("Location: admin.php");

         	  }

         	 $output .= "you have logged-In";
         }else{
             $output .= "Failed to login";
         }

  	   }
  }




 ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Login</title>

</head>
<style type="text/css">
	.bgcolor{
		background-color: whitesmoke;
	}
	.container{
		position: fixed;
		left: 40%;
	}
	form{
		background-color: white;
		border-radius: 2.3rem;
		padding: 20px;
	}
	h3{
		font-family: 'Poppins', sans-serif;
	}
	.bgimg{
		position: fixed;
		left: 100px;
		bottom: 200px;
		height: 50%;

    	}

	.img img{
		position: fixed;
		left: 100px;
		bottom: 200px;
		height: 50%;
		width: 50%;
	}
	lord-icon{
		position: relative;
		left: 24%;
	}
</style>
<body class="bgcolor">
	<?php include("includes/header.php"); ?>

<img class="bgimg" src="img/bg.png">
	<div class="imgqr">
		<div class="img">
			<img src="img/qrcode index.svg">
		</div>


	<div class="container">
		<div class="col-md-12">
			<div class="row d-flex justify-content-center">
				<div class="col-md-6 shadow-sm" style="margin-top:15px;">
					<form method="post">
						<script src="https://cdn.lordicon.com/libs/mssddfmo/lord-icon-2.1.0.js"></script>
						<lord-icon
    							src="https://cdn.lordicon.com/dxjqoygy.json"
    							trigger="loop"
    							colors="primary:#121331,secondary:#08a88a"
    							style="width:250px;height:250px">
						</lord-icon>
						<h3 class="text-center my-3">Login</h3>
						<div class="text-center"><?php echo $output; ?></div>
						<label>Username</label>
						<input type="text" name="uname" class="form-control my-2" placeholder="Enter Username" autocomplete="off">
                         
                         <label>Select User Type</label>
						<select name="utype" class="form-control my-2">
							<option value="0" disabled selected>Choose user type</option>
							<option value="Student">Student</option>
							<option value="Professor">Professor</option>
							<option value="Admin">Admin</option>
						</select>

						<label>Password</label>
						<input type="password" name="pass" class="form-control my-2" placeholder="Enter Password">

						<input type="submit" name="login" class="btn btn-success" value="Login">
						<a href="#">Log in using Qr code</a>
					</form>
				</div>
			</div>
		</div>
	</div>

</body>
</html>